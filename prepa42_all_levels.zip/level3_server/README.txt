
Prépa42 - Niveau 3 (Serveur)
----------------------------
Contenu:
- app.py : application Flask minimale (auth simple via users.json)
- templates/ : pages (index, login, register, dashboard)
- data/ : créé automatiquement pour stocker uploads et users.json

Pour démarrer:
1. python3 -m venv venv
2. source venv/bin/activate
3. pip install -r requirements.txt
4. flask run  (ou python app.py)
