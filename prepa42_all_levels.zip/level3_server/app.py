from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
import os, json, hashlib, datetime

app = Flask(__name__)
app.secret_key = 'change_me_to_a_strong_secret'
DATA_DIR = os.path.join(app.root_path, 'data')
os.makedirs(DATA_DIR, exist_ok=True)
USERS_FILE = os.path.join(DATA_DIR, 'users.json')
# simple user store
if not os.path.exists(USERS_FILE):
    with open(USERS_FILE,'w') as f:
        json.dump({}, f)

def load_users():
    with open(USERS_FILE,'r') as f:
        return json.load(f)
def save_users(u):
    with open(USERS_FILE,'w') as f:
        json.dump(u,f, indent=2)

@app.route('/')
def index():
    if 'user' in session:
        return render_template('dashboard.html', user=session['user'])
    return render_template('index.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method=='POST':
        username = request.form['username']
        password = request.form['password']
        users = load_users()
        if username in users:
            flash('Nom d\\' + 'utilisateur existant')
            return redirect(url_for('register'))
        users[username] = {'pwd': hashlib.sha256(password.encode()).hexdigest(), 'created': str(datetime.date.today())}
        save_users(users)
        flash('Compte créé, connecte-toi.')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        username = request.form['username']
        password = request.form['password']
        users = load_users()
        if username in users and users[username]['pwd']==hashlib.sha256(password.encode()).hexdigest():
            session['user']=username
            flash('Connecté.')
            return redirect(url_for('index'))
        flash('Identifiants incorrects.')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('Déconnecté.')
    return redirect(url_for('index'))

@app.route('/upload', methods=['POST'])
def upload():
    if 'user' not in session:
        flash('Connecte-toi pour uploader.')
        return redirect(url_for('login'))
    f = request.files.get('codefile')
    if not f:
        flash('Aucun fichier reçu.')
        return redirect(url_for('index'))
    user_dir = os.path.join(DATA_DIR, session['user'])
    os.makedirs(user_dir, exist_ok=True)
    filename = f.filename
    path = os.path.join(user_dir, filename)
    f.save(path)
    flash('Fichier sauvegardé.')
    return redirect(url_for('index'))

@app.route('/files/<user>/<filename>')
def files(user, filename):
    user_dir = os.path.join(DATA_DIR, user)
    return send_from_directory(user_dir, filename)

if __name__=='__main__':
    app.run(debug=True)
